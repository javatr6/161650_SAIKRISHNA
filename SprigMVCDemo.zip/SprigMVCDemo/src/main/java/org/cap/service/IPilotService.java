package org.cap.service;

import java.util.List;

import org.cap.model.City;
import org.cap.model.Pilot;

public interface IPilotService {
	public void savePilot(Pilot pilot);
	public List<Pilot> getPilotDetails();
	public void deletePilot(Integer pilotId);
	public Pilot updatePilot(Pilot p);
	public Pilot getPiotById(Integer pilotId);
	public List<City> getAllCities();
}
