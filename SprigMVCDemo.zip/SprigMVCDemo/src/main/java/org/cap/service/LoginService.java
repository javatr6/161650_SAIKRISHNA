package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.IPilotDao;
import org.cap.model.Login;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("loginService")
public class LoginService implements ILoginService{
	@Autowired
    private ILoginDao loginDao;
	@Override
	public boolean validateLogin(Login login) {
		
		return loginDao.validateLogin(login);
	}

}
