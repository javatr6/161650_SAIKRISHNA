package org.cap.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;


import javax.persistence.JoinColumn;


@Entity
public class AirCraft {
	
	@Id
	private int airCraftid;
	private String airCraftName;
	@ManyToMany
	@JoinTable(name="pilotaircraft",joinColumns= {@JoinColumn(name="airCraftid")},
			inverseJoinColumns= {@JoinColumn(name="pilotId")}) 
	List<Pilot> pilots=new ArrayList<>();
	public int getAirCraftid() {
		return airCraftid;
	}
	public void setAirCraftid(int airCraftid) {
		this.airCraftid = airCraftid;
	}
	public String getAirCraftName() {
		return airCraftName;
	}
	public void setAirCraftName(String airCraftName) {
		this.airCraftName = airCraftName;
	}
	@Override
	public String toString() {
		return "AirCraft [airCraftid=" + airCraftid + ", airCraftName=" + airCraftName + "]";
	}
	public AirCraft() {
		super();
	}
	

}
