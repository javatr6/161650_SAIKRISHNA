package com.capgemini.model;

import javax.persistence.Entity;

@Entity
public class Module extends Project {
	private String mouduleName;

	public String getMouduleName() {
		return mouduleName;
	}

	public void setMouduleName(String mouduleName) {
		this.mouduleName = mouduleName;
	}

	public Module(int projectId, String projectName, String mouduleName) {
		super(projectId, projectName);
		this.mouduleName = mouduleName;
	}

	public Module() {
		super();
	}


	public Module(int projectId, String projectName) {
		super(projectId, projectName);
	}

	@Override
	public String toString() {
		return "Module [mouduleName=" + mouduleName + "]";
	}
	

}
