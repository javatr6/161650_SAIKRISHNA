package com.capgemini.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Customer {
	@Id
	@GeneratedValue
	private int customerId;
	private String firstName;
	private String lastName;
	private int regFees;
	public Customer() {
		super();
	}
	public Customer(int customerId, String firstName, String lastName, int regFees) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.regFees = regFees;
	}
	public Customer(String firstName, String lastName, int regFees) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.regFees = regFees;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getRegFees() {
		return regFees;
	}
	public void setRegFees(int regFees) {
		this.regFees = regFees;
	}
	
	

}
