package com.capgemini.model;

import javax.persistence.Entity;

@Entity
public class Task  extends Module{
	private String taskName;

	public Task() {
		super();
	}


public Task(int projectId, String projectName, String mouduleName, String taskName) {
		super(projectId, projectName, mouduleName);
		this.taskName = taskName;
	}








	public Task(int projectId, String projectName, String mouduleName) {
		super(projectId, projectName, mouduleName);
	}








	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	
	

	@Override
	public String toString() {
		return "Task [taskName=" + taskName + "]";
	}

	

}
