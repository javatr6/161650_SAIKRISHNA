package com.capgemini.pi;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.model.Module;
import com.capgemini.model.Project;
import com.capgemini.model.Task;

public class InheritanceTester {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		Project project=new Project(100,"capgemini");
		com.capgemini.model.Module module=new Module();
		module.setMouduleName("jap");
		module.setProjectName("capg");
		module.setProjectId(101);
		Task task=new Task();
		task.setTaskName("Inheritance Task");
		task.setMouduleName("day5-jpa");
		task.setProjectName("capgemini project");
		task.setProjectId(102);
		entityManager.persist(project);
		entityManager.persist(module);
		entityManager.persist(task);
		transaction.commit();
		entityManager.close();

	}

}
