package com.capgemini.pi;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.model.Address;
import com.capgemini.model.Customer;

public class CustomerTester {

	public static void main(String[] args) {
	
		
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
					EntityManager entityManager=emf.createEntityManager();
					EntityTransaction transaction=entityManager.getTransaction();
					
					transaction.begin();
					
					Customer cust1=new Customer("sai","krishna",20000);
					Address address1=new Address(1001,"Hyd",cust1);
					
					Customer cust2=new Customer("krishna","sai",10000);
					Address address2=new Address(1002,"Delhi",cust2);
					
					entityManager.persist(cust1);
					entityManager.persist(address1);
					
					
					entityManager.persist(cust2);
					entityManager.persist(address2);
					
					transaction.commit();
					entityManager.close();
					 
			 

	}

}
