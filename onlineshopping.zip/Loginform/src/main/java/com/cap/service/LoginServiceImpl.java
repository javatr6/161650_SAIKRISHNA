package com.cap.service;

import com.cap.dao.ILoginDao;
import com.cap.dao.LoginDaoImpl;
import com.cap.model.LoginBean;

public class LoginServiceImpl implements ILoginService {
	private ILoginDao loginDaoImpl;
	
	{
		this.loginDaoImpl=new LoginDaoImpl();
	}

	

	

	@Override
	public boolean isValid(LoginBean loginBean) {
	if(loginDaoImpl.isValid(loginBean))
	{
		return true;
	}else
		return false;
	}





}
