package com.cap.dao;

import com.cap.model.LoginBean;

public interface ILoginDao {
	public boolean isValid(LoginBean loginBean);


}
