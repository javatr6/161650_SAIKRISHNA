package com.cap.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cap.model.LoginBean;




		public class LoginDaoImpl implements ILoginDao{

			
			@Override
			public boolean isValid(LoginBean loginBean) {

				String sql = "select * from adminLogin where username =? and password=?";
				
				try(
						PreparedStatement pmt =getSqlConnection().prepareStatement(sql)
						){
					pmt.setString(1, loginBean.getUserName());
					pmt.setString(2, loginBean.getPassWord());
					
					ResultSet rs = pmt.executeQuery();
					if(rs.next()) {
						return true;
					}
					
				}catch(SQLException e) {
					e.printStackTrace();
				}
				
				return false;
			}
			
			public Connection getSqlConnection() throws SQLException {
				
				Connection con=null;
				
					try {
						Class.forName("com.mysql.jdbc.Driver");
						con=DriverManager.getConnection(  
						"jdbc:mysql://localhost:3306/capdb","root","India123"); 
					} catch (ClassNotFoundException e) {
						e.printStackTrace();
					}  

				return con;
			}

		} 
		 
