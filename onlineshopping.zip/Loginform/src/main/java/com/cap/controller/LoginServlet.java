package com.cap.controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public LoginServlet() {
        super();
      
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");

		String userName=request.getParameter("userName");
		String userPwd=request.getParameter("userPwd");
		
		if(userName.equals("tom") &&
				userPwd.equals("tom123")) {
			response.sendRedirect("pages/successfull.html");
		}else {
			//response.sendRedirect("index.html");
			PrintWriter pw=response.getWriter();
			pw.println("<font color=\"red\">	Enter user NAME and Password</font>");
			RequestDispatcher rd=request.getRequestDispatcher("index.html");
			rd.include(request, response);
		}
		
	}
	}

