package com.capgemini.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capgemini.model.Product;

public class ProductDaoImpl implements IproductDao{
	
	private static List<Product> products=dummyDB();

	public List<Product> getAllProducts() {
	
		return products;
	}

	private static List<Product> dummyDB() {
		List<Product> products=new ArrayList<Product>();
		products.add(new Product(1, "nokia"));
		products.add(new Product(2, "Sony z"));
		products.add(new Product(3, "iPhone se"));
		products.add(new Product(4, "vivo"));
		products.add(new Product(5, "oppo"));
		
		return products;
	}


	
			public List<Product> addProducts(Integer productId, String productName) {
				products.add(new Product(productId,productName));
				return products;
			}

			public List<Product> deleteProducts(Integer productId) {
				Iterator<Product> iterator=products.iterator();
				while(iterator.hasNext()) {
					Product product=iterator.next();
					if(product.getProductId().equals(productId)) {
						iterator.remove();
						break;
					}
				}
				return products;
			} 
			public Product findProducts(Integer productId) {
				Iterator<Product> iterator = products.iterator();
				while(iterator.hasNext()) {
					Product product=iterator.next();
					if(product.getProductId().equals(productId)) {

						return product;

					}
				}
				return null;
			}

			public List<Product> updateProducts(Integer productId, String productName) {
				Iterator<Product> iterator = products.iterator();
				while(iterator.hasNext()) {
					Product product=iterator.next();
					if(product.getProductId().equals(productId)) {
						product.setProductName(productName);
						break;

					}
				}
				return products;

			} 


}
