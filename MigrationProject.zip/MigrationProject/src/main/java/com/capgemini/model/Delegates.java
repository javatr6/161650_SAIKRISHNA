package com.capgemini.model;


	
	
import java.util.ArrayList;
		import java.util.List;

		import javax.persistence.Entity;
		import javax.persistence.Id;
		import javax.persistence.JoinColumn;
		import javax.persistence.JoinTable;
		import javax.persistence.ManyToMany;
		@Entity
		public class Delegates {
			
			@Id
			private int delegateId;
			private String delegateName;
			@ManyToMany
			@JoinTable(name="event_delegate",joinColumns= {@JoinColumn(name="delegate_id")},
			inverseJoinColumns= {@JoinColumn(name="event_name")}) 
			List<Events> events =new ArrayList<>();
			public Delegates() {
				super();
			}
			public Delegates(int delegateId, String delegateName) {
				super();
				this.delegateId = delegateId;
				this.delegateName = delegateName;
			}
			public Delegates(int delegateId, String delegateName, List<Events> events) {
				super();
				this.delegateId = delegateId;
				this.delegateName = delegateName;
				this.events = events;
			}
			public int getDelegateId() {
				return delegateId;
			}
			public void setDelegateId(int delegateId) {
				this.delegateId = delegateId;
			}
			public String getDelegateName() {
				return delegateName;
			}
			public void setDelegateName(String delegateName) {
				this.delegateName = delegateName;
			}
			public List<Events> getEvents() {
				return events;
			}
			public void setEvents(List<Events> events) {
				this.events = events;
			}
			@Override
			public String toString() {
				return "Delegates [delegateId=" + delegateId + ", delegateName=" + delegateName + ", events=" + events + "]";
			}
			
		} 
		 



