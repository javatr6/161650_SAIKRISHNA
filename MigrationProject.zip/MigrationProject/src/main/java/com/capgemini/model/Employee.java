package com.capgemini.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


		
		@Entity
		public class Employee {
			@Id
			private int employeeId;
			public LocalDate getEmployeeDOJ() {
				return employeeDOJ;
			}




			public void setEmployeeDOJ(LocalDate employeeDOJ) {
				this.employeeDOJ = employeeDOJ;
			}




			public Company getCompany() {
				return company;
			}




			public void setCompany(Company company) {
				this.company = company;
			}




			private String employeeName;
			private LocalDate employeeDOJ;
			
			@ManyToOne
			@JoinColumn(name="companyfk")
			private Company company;
			
			public Employee() {
				super();
			}




			public Employee(String employeeName) {
				super();
				this.employeeName = employeeName;
			}




			public Employee(int employeeId, String employeeName, LocalDate employeeDOJ, Company company) {
				super();
				this.employeeId = employeeId;
				this.employeeName = employeeName;
				this.employeeDOJ = employeeDOJ;
				this.company = company;
			}




			public Employee(int employeeId, String employeeName, Company company) {
				super();
				this.employeeId = employeeId;
				this.employeeName = employeeName;
				this.company = company;
			}




			public Employee(int employeeId, String employeeName) {
				super();
				this.employeeId = employeeId;
				this.employeeName = employeeName;
			}




			public int getEmployeeId() {
				return employeeId;
			}




			public void setEmployeeId(int employeeId) {
				this.employeeId = employeeId;
			}




			public String getEmployeeName() {
				return employeeName;
			}




			public void setEmployeeName(String employeeName) {
				this.employeeName = employeeName;
			}




			@Override
			public String toString() {
				return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + "]";
			}
			
			

		} 
		 


