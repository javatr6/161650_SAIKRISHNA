package com.capgemini.pi;
import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.model.Company;
import com.capgemini.model.Employee;


public class EmployeeTester {
	public static void main(String args[]) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		
		Company company1=new Company("TCS");
		Company company2=new Company("Wipro");
		Company company3=new Company("Infosys");
		
		Employee employee1=new Employee(1001,"sai",company1);
		employee1.setEmployeeDOJ(LocalDate.of(2018, 9, 19));
		Employee employee2=new Employee(1002,"krishna",company2);
		employee2.setEmployeeDOJ(LocalDate.now());
		Employee employee3=new Employee(1003,"adf",company3);
		employee3.setEmployeeDOJ(LocalDate.of(1996, 10, 28));
		Employee employee4=new Employee(1004,"mahuya",company3);
		employee4.setEmployeeDOJ(LocalDate.of(1547, 2, 12));
	
		entityManager.persist(company1);
		entityManager.persist(company2);
		entityManager.persist(company3);
		 
		entityManager.persist(employee1);
		entityManager.persist(employee2);
		entityManager.persist(employee3);
		entityManager.persist(employee4);
		
		transaction.commit();
		entityManager.close();
	}

} 
 
