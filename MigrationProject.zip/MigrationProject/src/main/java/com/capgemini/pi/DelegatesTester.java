package com.capgemini.pi;

		import java.time.LocalDate;

import javax.persistence.EntityManager;
		import javax.persistence.EntityManagerFactory;
		import javax.persistence.EntityTransaction;
		import javax.persistence.Persistence;

import com.capgemini.model.Delegates;
import com.capgemini.model.Events;

	

		public class DelegatesTester {

			public static void main(String[] args) {
				// TODO Auto-generated method stub
				EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
				EntityManager entityManager=emf.createEntityManager();
				EntityTransaction transaction=entityManager.getTransaction();
				
				transaction.begin();
				
				Events servlets=new Events("123","servlets");
				servlets.setEventDate(LocalDate.now());
				
				Events python=new Events("456","python");
				python.setEventDate(LocalDate.of(1998, 5, 6));
				Events iot=new Events("789","iot");
				iot.setEventDate(LocalDate.of(1958, 5, 4));
				
				
				Delegates delagates1=new Delegates(1,"sai");
				Delegates delagates2=new Delegates(2,"ram");
				Delegates delagates3=new Delegates(3,"krish");
				Delegates delagates4=new Delegates(51,"seetha");
				Delegates delagates5=new Delegates(16,"john");
				Delegates delagates6=new Delegates(71,"tom");
				
				delagates1.getEvents().add(servlets);
				delagates1.getEvents().add(iot);
				delagates2.getEvents().add(python);
				delagates3.getEvents().add(iot);
				delagates3.getEvents().add(servlets);
				delagates4.getEvents().add(python);
				delagates5.getEvents().add(iot);
				delagates6.getEvents().add(servlets);
				delagates5.getEvents().add(python);
				
				entityManager.persist(delagates1);
				entityManager.persist(delagates2);
				entityManager.persist(delagates3);
				entityManager.persist(delagates4);
				entityManager.persist(delagates5);
				entityManager.persist(delagates6);
				entityManager.persist(servlets);
				entityManager.persist(python);
				entityManager.persist(iot);
				
				transaction.commit();
				entityManager.close();

			}

		} 
		 

	
	

