package org.cap.demo;

public class Task2   {

}
